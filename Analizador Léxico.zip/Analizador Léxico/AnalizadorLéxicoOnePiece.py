# Naal Uicab Christian Gabriel
# Poot Velazquez Carlos Gabriel
# Sosa Canché Rebeca Mireoli
# Tenorio Cauich Sharely Yannelis

import codecs
import ply.lex as lex
import sys
from ply.lex import Lexer
from tabulate import tabulate

reserved = {
    'arcsin':'ARCOSENO',
    'raiz':'RAIZ',
    'mostrar':'MOSTRAR',
    'sin':'SENO',
    'cos':'COSENO',
    'tan':'TANGENTE',
    'cosc':'COSECANTE',
    'sec':'SECANTE',
    'cot':'COTANGENTE',
    'Nami':'TIPO_DE_DATO',
    'robin':'TIPO_DE_DATO',
    'luffy':'TIPO_DE_DATO',
    'Mostrar':'VARIABLE_PARA_IMPRIMIR'
}

tokens = list(reserved.values()) + [
    #Simbolos
    'OPARENT',
    'CPARENT',
    'DIV',
    'MUL',
    'RESTA',
    'ADD',
    'EQUAL',
    'DEQUAL',
    'MAYORQUE', 
    'MENORQUE',
    'MAYORIGUAL', 
    'MENORIGUAL',
    'ASSIGN',
    'UNION',
    
    #Others
    'VARIABLE',
    'NUMBER',
    'CADENAVACIA',
    'CADENA',
    'ID',
]

t_OPARENT = r'\('
t_CPARENT = r'\)'
t_DIV = r'/'
t_MUL = r'\.'
t_RESTA = r'-'
t_ADD = r'\+'
t_EQUAL = r'=='
t_DEQUAL = r'!='
t_MAYORQUE = r'>'
t_MAYORIGUAL = r'>='
t_MENORQUE = r'>'
t_MENORIGUAL = r'<='
t_ASSIGN = r'::'

def t_IGUALDADES(t):
    r'([a-zA-Z]([\w])*) ([<|<=|=|>|>=])\s*[a-zA-Z]([\w])*'
    return t

def t_CADENAVACIA(t):
    r'\"\"'
    return t

def t_NUMBER(t):
    r'\d+(\.\d+)*'
    return t

def t_UNION(t):
    r'&'
    return t

def t_VARIABLE(t):
    r'[a-zA-Z]([\w])*'
    if t.value in reserved:
        t.type = reserved[t.value]
        return t
    else:
        return t

def t_ID(t):
    r'[a-zA-Z_][a-zA-Z_0-9]*'
    if t.value in reserved:
        t.type = reserved[t.value]
        return t
    else:
        t_error(t)

def t_CADENA(t):
    r'(\"[a-záéíóúÁÉÍÓÚ A-Z0-9]*\:*)\s*([a-z A-Z0-9]*\:*\")'
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

def t_space(t):
    r'\n|\r|\r\n|\s|\t'

t_ignore = ' \t'

def t_COMENTARIOENLINEAS(t):
    r'([\{,\-])\s*([a-zA-Z]\s*([\w])*)'

def t_COMENTARIOSENLINEA(t):
    r'\#.+'

def t_error(t):
    print("Lexical error: " + str(t.value))
    t.lexer.skip(1)

def test(data, lexer):
    lexer.input(data)
    row  = []
    i = 1
    while True:
        tok = lexer.token()
        if not tok:
            break
        row.append([i,tok.type,tok.value,tok.lineno])
        i += 1
    print (tabulate(row, headers=['NUM','Type','VALUE','LINE'], tablefmt='orgtbl'))
        

lexer = lex.lex()

if __name__ == '__main__':
    if len(sys.argv) <= 1:
        fin = 'OnePiece.hs'
    else:
        fin = sys.argv[1]
    f = codecs.open(fin, "r","utf-8")
    data = f.read()
    test(data, lexer)