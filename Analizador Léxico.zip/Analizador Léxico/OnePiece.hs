#Ejercicio1
Nami e1Hip :: (20 / Sin (30)) . 12
Mostrar ("El precio del cable es: " & precio)

#Ejercicio2
Nami altura :: 8 / cos (36-87)
Mostrar ("La altura del árbol es: " & altura) 

#Ejercicio3
Nami mediana :: 12 . sin (60)
Mostrar ("La mediana mide: " & mediana)

#Ejercicio4
Nami e4SumaCuadrados :: cuadrado (4) + cuadrado (3)
Nami e4Hip :: raiz (e4SumaCuadrados)
Nami e4Ang1 :: arcsin (0.6)
Nami e4Ang2 :: arcsin (0.8)
Mostrar ("Ángulo a: " & e4Ang1 & "Ángulo b: " & e4Ang2)

#Ejercicio5
Nami e5Angs :: ( 180 - 50 ) / 2
Nami e5b :: 10 . cos (e1Angs)
Nami e5Radio :: 2 . e5b
Mostrar ("El radio es: " & e5Radio)

#Ejercicio6
Nami e6Hip :: 271 / cos (30)  
Nami e6Altura :: e6Hip . sin (30)
Mostrar ("La altura es: " & e6Altura)

#Ejercicio7 (3)
Nami e7mediana :: 12 . sin (60)
Mostrar ("La mediana mide: " & e7mediana)

#Ejercicio8 (1)
Nami e8Hip :: 20 / Sin (30) . 12
Mostrar ("El precio del cable es: " & e8precio)

#Ejercicio9 (5) 
Nami e9Angs :: ( 180 - 50 ) / 2
Nami e9b :: 10 . cos (e9Angs)
Nami e9Radio :: 2 . e5b
Mostrar ("El radio es: " & e9Radio)

#Ejercicio10 (6)
Nami e10Hip :: 271 / cos (30)  
Nami e10Altura :: e10Hip . sin (30)
Mostrar ("La altura es: " & e10Altura)


